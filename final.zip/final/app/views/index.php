<!DOCTYPE html>
<html lang="en">

<head>
	<!-- Basic informations -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<!-- Site informations -->
	<title>Empório</title>

	<!-- Stylesheets -->
	<link href="./public/css/bootstrap.css" rel="stylesheet">
	<link href="./public/index/css/global.css" type="text/css" rel="stylesheet" media="all">
	<link href="./public/css/index.css" type="text/css" rel="stylesheet" media="all">
	<link href="./public/index/css/login.css" type="text/css" rel="stylesheet" media="all">
	<link href="./public/css/index.css" type="text/css" rel="stylesheet" media="all">
	<link href="./public/css/register.css" type="text/css" rel="stylesheet" media="all">

</head>

<body>
	<!-- Header -->	

  <header class="header" id="top">

		<div class="header__wrapper">

			<div class="login">
				<form role="search" action="/login" method="post">

					<div class="form-group">
						<input type="email" class="form-control" name="email" placeholder="Email">
					</div>

					<div class="form-group">
						<input type="password" class="form-control" name="senha" placeholder="Senha">
					</div>
					<div class="form-group">
						<button type="submit" class="btn btn-primary botao">Entrar</button>
					</div>
					
				</form>
				
			</div>
			</div>
		</div>

	
    <div class="container4  " >
		<div>
        <h1><p>Empório Hotel</p></h1>
		<div class="container1"><a  class="btn btn-primary botao btn-lg" href="/register" role="button">Cadastrar</a></div>
      </div>
					<!--alerta pro index-->
			<div class="alerta">
					  	<?php if($flash) { ?>
                <div class="alert alert-danger text-center" role="alert"><?= $flash ?></div>
            <?php } ?></div> 	

    </div>




	</header>


	

</body>

</html>