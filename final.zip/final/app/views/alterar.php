<!DOCTYPE html>
<html lang="en">

<head>
    <title></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="./public/css/bootstrap.css" rel="stylesheet">
    <link href="./public/css/register.css" rel="stylesheet">
    <link href="./public/css/index.css" type="text/css" rel="stylesheet" media="all">
</head>

<body  >
<header class="header">
<div class="container">
 <div class="container5" ><a  class="btn btn-primary botao" href="/start" role="button">Voltar</a></div>
 
        <div class="card card-container">

            <?php if($flash) { ?>
                <div class="alert alert-danger text-center" role="alert"><?= $flash ?></div>
            <?php } ?>

            <form class="form-signin" method="post" action="/alterado">
            <h1 class="text-center">Alterar</h1>
                <input type="text" id="inputNome" name="nome" class="form-control" placeholder="Nome" value="<?=$cadastrado['nome']?>" required>
                <input type="text" id="inputRg" name="rg" class="form-control" placeholder="RG" value="<?=$cadastrado['RG']?>"required>
                <!--selecionar o sexo-->
<div class="form-element" id="gender-form-element">
  <label id="gender-label">
  <div  id="GenderHolder" >
  <select  id="Gender" name="sexo" required>
  <option value="">Sou do sexo...</option>
  <option  value="feminino" >
  Feminino</option>
  <option  value="masculino" >
  Masculino</option>
  <option  value="outro" >
  Outro</option>
  <option  value="sem divulgacao" >
  Prefiro não divulgar</option>
  </select>
  </div>
  </label>
  </div>
                <input type="text" id="inputTelefone" name="telefone" class="form-control" placeholder="Telefone" value="<?=$cadastrado['telefone']?>" required>
                <input type="text" id="inputTelefone1" name="telefone_extra" class="form-control" placeholder="telefone (opcional)" value="<?=$cadastrado['telefone_extra']?>">
                <input type="text" id="inputEstado" name="estado" class="form-control" placeholder="Estado" value="<?=$cadastrado['estado']?>" required>
                <input type="text" id="inputCep" name="cep" class="form-control" placeholder="CEP" value="<?=$cadastrado['cep']?>" required>
                
                <button class="btn btn-large btn-primary botao" type="submit">Alterar</button>
            </form><!-- /form -->
           
        </div><!-- /card-container -->
    </div><!-- /container -->
    </header>

  
 
</body>

</html>