<?php
//senhor ou senhora
if($cadastrado['sexo']=="feminino"){
 $saudaçao="Seja Bem vinda";
}else{
    $saudaçao="Seja Bem vindo";
}
?>


    <!DOCTYPE html>
    <html lang="en">

    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="./public/css/bootstrap.css" rel="stylesheet">
        <link href="./public/css/reserva.css" rel="stylesheet">
        <link href="./public/css/register.css" rel="stylesheet">
<!--        <link href="./public/css/index.css" type="text/css" rel="stylesheet" media="all">-->
        <link href="./public/css/usuario.css" rel="stylesheet">
    </head>


    <body class="fundo2" style="overflow-x:hidden">





        <div class="row">
            <div class="col-md-1"></div>
        </div>
        <!--quartos-->



        <div class="row col-md-offset-1 login">
            <?php foreach($quarto as $d) { ?>
            <div class="col-md-5 cardi card-container" style="margin-right: 35px">
              <center><img src="../../public/index/img/hotel4.jpg" style="width:400px;border-radius: 3px; margin-left: 20px; margin-right: 20px"></img></center>
                </br>

                <div>
                    <div class="col-md-5" style="margin-left: 0">
                Numero: <?=$d['idquarto']?>
                    </div>
                    <div class="col-md-5">
                Andar: <?=$d['andar']?>
                    </div>
                </div>
                </br>
                <form class="form-signin" method="post"  style="margin-top: 10px;" action="/cadastroReserva">

                
                    <input style="margin-left: 14px; margin-right: 20px;" class="form-control" type="text" name="adulto" placeholder="Quantidade de Adulto" required> 
                    <input style="margin-left: 14px;" class="form-control" type="text" name="crianca" placeholder="Quantidade de Crianças"  required> 
                           
                    <input type="hidden" name="idquarto" value="<?=$d['idquarto']?>">
                    <label style="margin-left: 14px">Entrada</label>
                    <input type="date" name="entrada" required>
                    <label style="margin-left: 40px">Saída</label>
                    <input type="date" name="saida" required>
                    
                    <div style="margin-top: 20px;">
                   <button class="btn btn-primary botao">Reservar</button>
                    </div>

                </form>
            </div>
            <?php } ?>
        </div>


        <!--botoes da patte de cima (logout)-->
        <header class="header2">

            <div class="row titulo"> Empório Hotel </div>

            <div class="container3"><a class="btn btn-primary botao" href="/logout" role="button">Logout</a></div>

            <div class="row usuario">
                <?="Olá"." ".$cadastrado['nome']."!"?>
            </div>

            <div class="row saudacao">
                <?=$saudaçao?>
            </div>

        </header>


    </body>

    </html>