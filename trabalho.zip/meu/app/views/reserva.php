<?php
//senhor ou senhora
if($cadastrado['sexo']=="feminino"){
 $saudaçao="Seja Bem vinda";
}else{
    $saudaçao="Seja Bem vindo";
}
?>


    <!DOCTYPE html>
    <html lang="en">

    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="./public/css/bootstrap.css" rel="stylesheet">
        <link href="./public/css/reserva.css" rel="stylesheet">
        <link href="./public/css/register.css" rel="stylesheet">
        <link href="./public/css/index.css" type="text/css" rel="stylesheet" media="all">
        <link href="./public/css/usuario.css" rel="stylesheet">
    </head>


    <body class="fundo2">





        <div class="row">
            <div class="col-md-1"></div>
        </div>
        <!--quartos-->



        <div class="row col-md-offset-1">
            <?php foreach($quarto as $d) { ?>
            <div class="col-md-5 cardi card-container" style="margin-right: 10px">
              <center><img src="../../public/index/img/hotel4.jpg" style="width:400px;border-radius: 3px;"></img></center>
                </br>
                <p>Numero: <?=$d['idquarto']?></p>
                <p>Andar: <?=$d['andar']?></p>
                <form action="post" action="/reserva">
                    <input type="hidden" name="id-quarto" value="<?=$d['idquarto']?>">
                    <input type="date" name="entrada">
                    <input type="date" name="saida">
                    <button>Reservar</button>
                </form>
            </div>
            <?php } ?>
        </div>


        <!--botoes da patte de cima (logout)-->
        <header class="header2">

            <div class="row titulo"> Empório Hotel </div>

            <div class="container3"><a class="btn btn-primary botao" href="/logout" role="button">Logout</a></div>

            <div class="row usuario">
                <?="Olá"." ".$cadastrado['nome']."!"?>
            </div>

            <div class="row saudacao">
                <?=$saudaçao?>
            </div>

        </header>


    </body>

    </html>