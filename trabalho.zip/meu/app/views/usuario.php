<?php
//senhor ou senhora
if($cadastrado['sexo']=="feminino"){
 $saudaçao="Bem vinda";
}else{
    $saudaçao="Bem vindo";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="./public/css/bootstrap.css" rel="stylesheet">
    <link href="./public/css/register.css" rel="stylesheet">
    <link href="./public/css/usuario.css" rel="stylesheet">
    <link href="./public/css/index.css" type="text/css" rel="stylesheet" media="all">
</head>



<body >
 

 <header class="header2"  >
 <div class="container3"><a  class="btn btn-primary botao" href="/logout" role="button">Logout</a></div>
      <div class="row titulo" align="center"> Empório hotel </div>
   <div class="row">
   <div class="usuario"><?=$saudaçao." ".$cadastrado['nome']?></div>
   </div>

<Div class="row">
<div class="col-md-1">
</div>
<div class="col-md-5">
 <div class="cardi card-container"> 
<table id="t01"  class="table table-hover" width=300 height=100  >    
 </header>



<thead>
    <tr>
    <td colspan="2"><h2>Dados cadastrais</h2></td>
    </tr>
</thead>
<tbody>
   <!--linha-->              
  <tr>
   <th>Nome:</th> 
   
    <th>
<?= $cadastrado['nome'];
?> </th>
   </tr>
  <!--linha-->
   <tr>
   <th>RG:</th>
    <th>
<?= $cadastrado['RG'];
?></th>
   </tr>

    <!--linha-->
    <tr>
   <th>sexo:</th>
    <th>
<?= $cadastrado['sexo'];
?></th>
   </tr>
    
    <!--linha-->
    <tr>
   <th>Email:</th>
    <th>
<?= $cadastrado['email'];
?></th>
   </tr>

    <!--linha-->
    <tr>
   <th>Telefone:</th>
    <th>
<?= $cadastrado['telefone'];
?></th>
   </tr>

     <!--linha-->
    <tr>
   <th>Telefone Extra:</th>
    <th>
<?= $cadastrado['telefone_extra'];
?></th>
   </tr>

    <!--linha-->
    <tr>
   <th>Estado:</th>
    <th>
<?= $cadastrado['estado'];
?></th>
   </tr>

    <!--linha-->
    <tr>
   <th>CEP</th>
    <th>
<?= $cadastrado['cep'];
?></th>
   </tr>
</tbody>
</table>
<!--tabela-->
 <div align="center" ><a  class="btn btn-primary botao" href="/alterar" role="button">Alterar dados</a></div>
 </div>
</div>
<div class="col-md-1"></div>
<div class="col-md-5">

     <div class="cardi card-container"> 
     </div>
</div>

</Div>
  
</body>
</html>