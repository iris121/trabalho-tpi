<?php
//senhor ou senhora
if($cadastrado['sexo']=="feminino"){
 $saudaçao="Seja Bem vinda";
}else{
    $saudaçao="Seja Bem vindo";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="./public/css/bootstrap.css" rel="stylesheet">
    <link href="./public/css/register.css" rel="stylesheet">
    <link href="./public/css/index.css" type="text/css" rel="stylesheet" media="all">
    <link href="./public/css/usuario.css" rel="stylesheet">
</head>



<body class="fundo2">
 




<div class="row">
<div class="col-md-1"></div>

<div class="col-md-4">
 <div class="cardi card-container"> 

<!--tabela-->


<table id="t01"  class="table table-hover" width=300 height=100  >    

<thead>
    <tr>
    <td colspan="2"><h2>Dados cadastrais</h2></td>
    </tr>
</thead>
<tbody>
   <!--linha-->              
  <tr>
   <th>Nome:</th> 
   
    <th>
<?= $cadastrado['nome'];
?> </th>
   </tr>
  <!--linha-->
   <tr>
   <th>RG:</th>
    <th>
<?= $cadastrado['RG'];
?></th>
   </tr>

    <!--linha-->
    <tr>
   <th>sexo:</th>
    <th>
<?= $cadastrado['sexo'];
?></th>
   </tr>
    
    <!--linha-->
    <tr>
   <th>Email:</th>
    <th>
<?= $cadastrado['email'];
?></th>
   </tr>

    <!--linha-->
    <tr>
   <th>Telefone:</th>
    <th>
<?= $cadastrado['telefone'];
?></th>
   </tr>

     <!--linha-->
    <tr>
   <th>Telefone Extra:</th>
    <th>
<?= $cadastrado['telefone_extra'];
?></th>
   </tr>

    <!--linha-->
    <tr>
   <th>Estado:</th>
    <th>
<?= $cadastrado['estado'];
?></th>
   </tr>

    <!--linha-->
    <tr>
   <th>CEP</th>
    <th>
<?= $cadastrado['cep'];
?></th>
   </tr>
</tbody> 
</table>

<!--Botões-->
<div class="row">
 <div class="col-md-6" align="left" ><a  class="btn btn-primary botao" href="/deletar" role="button">Deletar conta</a></div>
 <div class="col-md-1"></div>
 <div  <div class="col-md-3" align="right" ><a  class="btn btn-primary botao" href="/alterar" role="button">Alterar dados</a></div>
 </div>
 </div>
</div>

<div class="col-md-1"></div>



<!--2 cardi-->
<div class="col-md-5">

     <div class="cardi card-container"> 
<!--reservas antigas-->
<table id="t01"  class="table table-hover" width=300 height=100  >  
<thead>
    <tr>
    <td colspan="2" align="center"><h2>Reservas Anteriores</h2></td>
    </tr>
</thead>

 <?php foreach($hospedado as $d) { ?>
 
 <!--linha-->              
  <tr>
<!--coluna-->

<th>
    </br>
<section>

<div class='row'>    
<div class='col-md-6'>Data de entrada:<?=' '.$d['chek-in']?></div>
<div class='col-md-6'>Data de saída:<?=' '.$d['chek-out']?></div>
</div>


<div class='row'>    
<div class='col-md-6'>Quarto numero:<?=' '.$d['idquarto']?> </div>
</div>

<div class='row'>    
<div class='col-md-6'>Quantidade de Adulto:<?=' '.$d['qntd_adultos']?></div>
<div class='col-md-6'>Quantidade de Crianças:<?=' '.$d['qntd_criancas']?></div>

</div>
  
</section>    
</br>
    </th>
    </tr>
 
 <?php } ?>

</table>





<!--botao para nova reserva-->

<div  align="center" ><a  class="btn btn-primary botao" href="/reservar1" role="button">Nova Reserva</a></div>
</div>
</div>

</div>

<!--botoes da patte de cima (logout)-->
 <header class="header2"  >

 <div class="row titulo" > Empório Hotel </div>
  
   <div class="container3"><a class="btn btn-primary botao" href="/logout" role="button">Logout</a></div>

   <div class="row usuario"><?="Olá"." ".$cadastrado['nome']."!"?></div>

   <div class="row saudacao"><?=$saudaçao?></div>
   
</header> 
 
</body>
</html> 