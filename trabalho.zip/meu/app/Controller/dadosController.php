<?php
namespace Project\Controller;

use Project\Db\QueryBuilder;
use Project\Util\Flash;
use Project\Util\Login;

class dadosController
{
    //esse método é chamado quando a página inicial é acionada
    public function index()
    {

       
        // se estiver logado, vai para o começo do site
        if(Login::isLogged()){
        require './app/views/usuario.php';
             exit;
        } 
        else{

        //caso haja alguem disparando uma mensagem flash, recebe a mensagem
        $flash = Flash::getFlash();

        //chama a página principal
        require './app/views/index.php';}
        
    }
    
    public function start()
    {
//So permite que continue se estiver logada
        if(!Login::isLogged()){
            header('Location: /');
            exit;
        }

         $q = new QueryBuilder(); 
        $cadastrado = $q->select('hospede', ['email' => $_SESSION['user']], true);
       
       //salva o id
        $_SESSION['id']=$cadastrado['idhospede'];
        //print_r($_SESSION['id']);
         $hospedado = $q->select('hospedagem', ['idhospede' => $_SESSION['id']]);
                 
        require './app/views/usuario.php';

      
        }

        public function pagAlterar(){
            //So permite que continue se estiver logada
        if(!Login::isLogged()){
            header('Location: /');
            exit;
        }

         $q = new QueryBuilder();
        $cadastrado = $q->select('hospede', ['email' => $_SESSION['user']], true);
        //pega mensagem na funçao flash se tiver
        $flash = Flash::getFlash();
         require './app/views/alterar.php';
       // require './app/views/alterar.php';
           // print_r($cadastrado);
          // print_r($_SESSION['password']);
        }

        public function alterar(){
         if(!Login::isLogged()){
            header('Location: /');
            exit;
        }

        $dados['nome'] = htmlentities($_POST['nome'], ENT_QUOTES);
        $dados['rg'] = htmlentities($_POST['rg'], ENT_QUOTES);
        $dados['sexo'] = htmlentities($_POST['sexo'], ENT_QUOTES);
        $dados['telefone'] = htmlentities($_POST['telefone'], ENT_QUOTES);
        $dados['telefone_extra'] = htmlentities($_POST['telefone_extra'], ENT_QUOTES);
        $dados['estado'] = htmlentities($_POST['estado'], ENT_QUOTES);
        $dados['cep'] = htmlentities($_POST['cep'], ENT_QUOTES);

        //senha e email
        $dados['email']=$_SESSION['user'];
        $dados['senha']=$_SESSION['password'];
        print_r($_SESSION['password']);
        //altera dados do banco
        $q = new QueryBuilder();
        $cadastrado = $q->update('hospede', $dados, ['email' => $_SESSION['user']]);

//print_r($cadastrado);

     header('Location: /start');

  
    }

   public function deletar(){
          if(!Login::isLogged()){
            header('Location: /');
            exit;
        }
   $q = new QueryBuilder();
   $cadastrado = $q->delete('hospede', ['email' => $_SESSION['user']]);
        //remove todas variáveis criadas de sessão
        session_unset();

        //devolve para a página inicial
        header('Location: /');
die();
//print_r($_SESSION['user']);

    }


    public function reservar1(){
          if(!Login::isLogged()){
            header('Location: /');
            exit;
        }

         $q = new QueryBuilder();
        $cadastrado = $q->select('hospede', ['email' => $_SESSION['user']], true);
        $quarto = $q->select('quarto');
      
             //itens
        $itens = $q->selectItensQuarto($quarto[0]['idquarto']);


//print_r($cama);
//print_r($quarto);
//print_r($cadastrado);
require './app/views/reserva.php';

    }    

}