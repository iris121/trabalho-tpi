<?php
namespace Project\Controller;

use Project\Db\QueryBuilder;
use Project\Util\Flash;
use Project\Util\Login;

class dadosController
{
    //esse método é chamado quando a página inicial é acionada
    public function index()
    {

       
        // se estiver logado, vai para o começo do jogo
        if(Login::isLogged()){
        require './app/views/usuario.php';
             exit;
        }

        //caso haja alguem disparando uma mensagem flash, recebe a mensagem
        $flash = Flash::getFlash();

        //chama a página principal
        require './app/views/index.php';
        
    }
    
    public function start()
    {
//So permite que continue se estiver logada
        if(!Login::isLogged()){
            header('Location: /');
            exit;
        }

         $q = new QueryBuilder();
        $cadastrado = $q->select('hospede', ['email' => $_SESSION['user']], true);
        
        require './app/views/usuario.php';

      
        }

      
        
    }


