-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 23-Nov-2017 às 14:21
-- Versão do servidor: 10.1.13-MariaDB
-- PHP Version: 5.6.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `hospedagem`
--

CREATE TABLE `hospedagem` (
  `idhospedagem` int(11) NOT NULL,
  `idhospede` int(11) NOT NULL,
  `idquarto` int(11) NOT NULL,
  `chek-in` date NOT NULL,
  `qntd_adultos` int(11) NOT NULL,
  `qntd_criancas` int(11) NOT NULL,
  `chek-out` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `hospede`
--

CREATE TABLE `hospede` (
  `idhospede` int(11) NOT NULL,
  `nome` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `senha` varchar(45) NOT NULL,
  `RG` varchar(45) NOT NULL,
  `sexo` varchar(45) NOT NULL,
  `telefone` varchar(45) NOT NULL,
  `telefone_extra` varchar(45) DEFAULT NULL,
  `estado` varchar(2) NOT NULL,
  `cep` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `hospede`
--

INSERT INTO `hospede` (`idhospede`, `nome`, `email`, `senha`, `RG`, `sexo`, `telefone`, `telefone_extra`, `estado`, `cep`) VALUES
(1, 'inara Valim', 'i@i.com', '', '00', 'masculino', '100', '1000', '10', '1000'),
(7, 'inara Valim', 'bruno@d.com', '', '10', 'feminino', '10', '10', '10', '10'),
(8, 'iris', 'g@g.com', '10', '10', 'feminino', '10', '10', '10', '10');

-- --------------------------------------------------------

--
-- Estrutura da tabela `itens`
--

CREATE TABLE `itens` (
  `idquarto` int(11) NOT NULL,
  `iditens` int(11) NOT NULL,
  `quantidade` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `quarto`
--

CREATE TABLE `quarto` (
  `idquarto` int(11) NOT NULL,
  `andar` int(11) NOT NULL,
  `observacao` varchar(105) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `servicos`
--

CREATE TABLE `servicos` (
  `idhospedagem` int(11) NOT NULL,
  `idtipo_servicos` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo_itens`
--

CREATE TABLE `tipo_itens` (
  `iditens` int(11) NOT NULL,
  `nome` varchar(45) NOT NULL,
  `observacao` varchar(105) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo_servicos`
--

CREATE TABLE `tipo_servicos` (
  `idtipo_servicos` int(11) NOT NULL,
  `nome` varchar(45) NOT NULL,
  `valor` varchar(45) NOT NULL,
  `observacao` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hospedagem`
--
ALTER TABLE `hospedagem`
  ADD PRIMARY KEY (`idhospedagem`),
  ADD KEY `fk_hospedagem_hospede1_idx` (`idhospede`),
  ADD KEY `fk_hospedagem_quarto1_idx` (`idquarto`);

--
-- Indexes for table `hospede`
--
ALTER TABLE `hospede`
  ADD PRIMARY KEY (`idhospede`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `itens`
--
ALTER TABLE `itens`
  ADD PRIMARY KEY (`idquarto`,`iditens`),
  ADD KEY `fk_quarto_has_itens_quarto1_idx` (`idquarto`),
  ADD KEY `fk_quarto_itens_tipo_itens1_idx` (`iditens`);

--
-- Indexes for table `quarto`
--
ALTER TABLE `quarto`
  ADD PRIMARY KEY (`idquarto`);

--
-- Indexes for table `servicos`
--
ALTER TABLE `servicos`
  ADD PRIMARY KEY (`idhospedagem`,`idtipo_servicos`),
  ADD KEY `fk_servicos_hospedagem1_idx` (`idhospedagem`),
  ADD KEY `fk_servicos_tipo_servicos1_idx` (`idtipo_servicos`);

--
-- Indexes for table `tipo_itens`
--
ALTER TABLE `tipo_itens`
  ADD PRIMARY KEY (`iditens`);

--
-- Indexes for table `tipo_servicos`
--
ALTER TABLE `tipo_servicos`
  ADD PRIMARY KEY (`idtipo_servicos`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hospedagem`
--
ALTER TABLE `hospedagem`
  MODIFY `idhospedagem` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `hospede`
--
ALTER TABLE `hospede`
  MODIFY `idhospede` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `quarto`
--
ALTER TABLE `quarto`
  MODIFY `idquarto` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tipo_itens`
--
ALTER TABLE `tipo_itens`
  MODIFY `iditens` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tipo_servicos`
--
ALTER TABLE `tipo_servicos`
  MODIFY `idtipo_servicos` int(11) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `hospedagem`
--
ALTER TABLE `hospedagem`
  ADD CONSTRAINT `fk_hospedagem_hospede1` FOREIGN KEY (`idhospede`) REFERENCES `hospede` (`idhospede`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_hospedagem_quarto1` FOREIGN KEY (`idquarto`) REFERENCES `quarto` (`idquarto`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `itens`
--
ALTER TABLE `itens`
  ADD CONSTRAINT `fk_quarto_has_itens_quarto1` FOREIGN KEY (`idquarto`) REFERENCES `quarto` (`idquarto`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_quarto_itens_tipo_itens1` FOREIGN KEY (`iditens`) REFERENCES `tipo_itens` (`iditens`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `servicos`
--
ALTER TABLE `servicos`
  ADD CONSTRAINT `fk_servicos_hospedagem1` FOREIGN KEY (`idhospedagem`) REFERENCES `hospedagem` (`idhospedagem`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_servicos_tipo_servicos1` FOREIGN KEY (`idtipo_servicos`) REFERENCES `tipo_servicos` (`idtipo_servicos`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
